from flask import Flask, render_template as rt

app = Flask(__name__)

s = 'homework'
@app.route('/<path>') # 데코레이터 #/는 처음 시작하는 루트
def homework(path = None):
    if path == '1':
        return rt('homework.html')
    elif path == '2':
        return rt('homework1.html')
    elif path == '3':
        return rt('homework2.html')
    elif path == '4':
        return rt('homework3.html')
    elif path == '5':
        return rt('homework4.html')
    elif path == '6':
        return rt('homework5.html')
    elif path == '7':
        return rt('homework6.html')

    elif path == '8':
        return rt('homework7.html')

    elif path == '9':
        return rt('homework8.html')

    elif path == '10':
        return rt('homework9.html')
    elif path == '11':
        return rt('homework10.html')


@app.route('/') # 데코레이터 #/는 처음 시작하는 루트
def homework1():
        return rt('study.html')

if __name__ == '__main__':

    app.run()
